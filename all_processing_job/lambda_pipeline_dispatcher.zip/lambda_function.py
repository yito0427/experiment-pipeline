import json
import boto3

import yaml ### use lambda layer

codecommit = boto3.client('codecommit')

BUCKET_NAME = 'demo-mlops-tokyo'

def lambda_handler(event, context):
    print(event)
    commit_id_trigger = event['Records'][0]['codecommit']['references'][0]['commit']
    repository_name = event['Records'][0]['eventSourceARN'].split(':')[5]
    user_name = event['Records'][0]['userIdentityARN'].split('/')[1]
    event_time = event['Records'][0]['eventTime']
    
    res = codecommit.get_file(
        repositoryName=repository_name,
        filePath='experiment.yml'
    )
    commit_id_expyml = res['commitId']
    
    ### experiment.ymlのpushではなかった場合、終了
    if commit_id_trigger != commit_id_expyml:
        return {
            'statusCode': 200,
            'body': json.dumps('Pipeline was not launched due to no renewal of experiment.yml')
        }
    
    # ymlをパース
    param = yaml.safe_load(res['fileContent'])
    
    # コードはS3にコピーする
    s3 = boto3.client('s3')
    
    ### experiment.ymlをS3にファイルをアップロード
    s3.put_object(Bucket=BUCKET_NAME,
        Key=repository_name + "_" + user_name + "_" + event_time + "_" + commit_id_trigger + "/experiment.yml",
        Body=res['fileContent'])
    
    for key in param:
        if 'code' in param[key]:
            code_file = codecommit.get_file(
                repositoryName=repository_name,
                filePath=param[key]['code']
            )
            ### S3にファイルをアップロード
            s3.put_object(Bucket=BUCKET_NAME,
                #Key=repository_name + "_" + commit_id_trigger + "/" + param[key]['code'],
                Key=repository_name + "_" + user_name + "_" + event_time + "_" + commit_id_trigger + "/" + param[key]['code'],
                Body=code_file['fileContent'])
            ### paramのcodeファイルパスをS3 URIに書き換え
            param[key]['code'] = "s3://" + BUCKET_NAME + "/" + repository_name + "_" + user_name + "_" + event_time + "_" + commit_id_trigger + "/" + param[key]['code']
            param[key]['ContainerEntrypoint'] = "/opt/ml/processing/input/code/" + param[key]['code'].split('/')[-1]
            param[key]['output_data_uri'] = "s3://" + BUCKET_NAME + "/" + repository_name + "_" + user_name + "_" + event_time + "_" + commit_id_trigger + "/" + key + "/"
    
    ### StepFunctions のパイプラインを起動
    stepfunctions = boto3.client('stepfunctions')
    param['id'] = commit_id_trigger
    resp = stepfunctions.start_execution(
            **{
              'input': json.dumps(param),
              'stateMachineArn': param['pipeline']['stateMachineArn']
              }
            )
    return {
        'statusCode': 200,
        'body': json.dumps('end of lambda')
    }